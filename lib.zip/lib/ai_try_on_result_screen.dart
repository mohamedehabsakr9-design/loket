import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app/app_strings.dart';

const String _kBase = 'https://lokit-production.up.railway.app';

class AiTryOnResultScreen extends StatefulWidget {
  final String resultImageUrl;
  final int? productId;

  const AiTryOnResultScreen({
    super.key,
    required this.resultImageUrl,
    this.productId,
  });

  @override
  State<AiTryOnResultScreen> createState() => _AiTryOnResultScreenState();
}

class _AiTryOnResultScreenState extends State<AiTryOnResultScreen> {
  bool _retrying = false;
  String? _currentUrl;

  @override
  void initState() {
    super.initState();
    _currentUrl = widget.resultImageUrl;
  }

  Future<void> _retry() async {
    final productId = widget.productId;
    if (productId == null || productId == 0) {
      _snack('No product to retry', err: true);
      return;
    }

    final picker = ImagePicker();
    final src = await _askSource();
    if (src == null || !mounted) return;

    final picked = await picker.pickImage(
      source: src,
      imageQuality: 85,
      maxWidth: 1080,
    );
    if (picked == null || !mounted) return;

    setState(() => _retrying = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = (prefs.getString('token') ??
              prefs.getString('jwt') ??
              prefs.getString('accessToken') ??
              '')
          .replaceFirst('Bearer ', '')
          .trim();

      final dio = Dio(BaseOptions(
        baseUrl: _kBase,
        connectTimeout: const Duration(seconds: 60),
        receiveTimeout: const Duration(seconds: 180),
        validateStatus: (s) => s != null && s < 600,
        headers: {
          if (token.isNotEmpty) 'Authorization': 'Bearer $token',
        },
      ));

      final imageFile = File(picked.path);

      final formData = FormData.fromMap({
        'userImage': await MultipartFile.fromFile(
          picked.path,
          filename: 'user_photo.jpg',
          contentType: DioMediaType('image', 'jpeg'),
        ),
      });

      print('POST $_kBase/ai/try-on?productId=$productId');
      print('token exists: ${token.isNotEmpty}');
      print('picked image path: ${picked.path}');
      print('picked image exists: ${await imageFile.exists()}');
      print('picked image size: ${await imageFile.length()} bytes');
      print('formData fields: ${formData.fields}');
      print(
        'formData files: ${formData.files.map((e) => '${e.key}: ${e.value.filename}').toList()}',
      );

      final response = await dio.post(
        '/ai/try-on',
        queryParameters: {'productId': productId},
        data: formData,
      );

      print('TryOn status: ${response.statusCode}');
      print('TryOn response data: ${response.data}');

      if (!mounted) return;

      if ((response.statusCode ?? 0) >= 400) {
        _snack(_extractError(response.data), err: true);
        return;
      }

      final url = _extractUrl(response.data);
      if (url == null || url.isEmpty) {
        _snack('No result image returned', err: true);
        return;
      }

      setState(() => _currentUrl = url);
    } on DioException catch (e) {
      print('DioException: ${e.message}');
      print('Dio status: ${e.response?.statusCode}');
      print('Dio data: ${e.response?.data}');

      if (!mounted) return;
      _snack(
        e.response != null
            ? _extractError(e.response!.data)
            : (e.message ?? 'Network error'),
        err: true,
      );
    } catch (e) {
      print('TryOn exception: $e');

      if (!mounted) return;
      _snack(e.toString().replaceFirst('Exception: ', ''), err: true);
    } finally {
      if (mounted) setState(() => _retrying = false);
    }
  }

  Future<ImageSource?> _askSource() async {
    return showModalBottomSheet<ImageSource>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 12),
            ListTile(
              leading: const Icon(Icons.camera_alt_outlined),
              title: const Text('Camera'),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Gallery'),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  String _extractError(dynamic body) {
    if (body is Map) {
      return (body['message'] ?? body['error'] ?? 'Server error').toString();
    }
    return body?.toString() ?? 'Unknown error';
  }

  String? _extractUrl(dynamic body) {
    if (body is Map) {
      return (body['resultImageUrl'] ??
              body['outputImageUrl'] ??
              body['imageUrl'] ??
              body['url'] ??
              body['result'])
          ?.toString();
    }
    if (body is String && body.startsWith('http')) return body;
    return null;
  }

  void _snack(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: err ? Colors.red : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final isAr = Localizations.localeOf(context).languageCode == 'ar';
    final url = _currentUrl ?? widget.resultImageUrl;

    return Directionality(
      textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(
            s.aiResultTitle,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          centerTitle: true,
          actions: [
            if (_retrying)
              const Padding(
                padding: EdgeInsets.only(right: 16),
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                ),
              )
            else
              IconButton(
                icon: const Icon(Icons.refresh, color: Colors.white),
                tooltip: 'Try again with a new photo',
                onPressed: _retry,
              ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: _retrying
                  ? const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(color: Colors.white),
                          SizedBox(height: 16),
                          Text(
                            'Generating result…',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    )
                  : InteractiveViewer(
                      child: Center(
                        child: Image.network(
                          url,
                          fit: BoxFit.contain,
                          loadingBuilder: (_, child, progress) {
                            if (progress == null) return child;
                            return Center(
                              child: CircularProgressIndicator(
                                value: progress.expectedTotalBytes != null
                                    ? progress.cumulativeBytesLoaded /
                                        progress.expectedTotalBytes!
                                    : null,
                                color: Colors.white,
                              ),
                            );
                          },
                          errorBuilder: (_, __, ___) => Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.broken_image_outlined,
                                color: Colors.white54,
                                size: 64,
                              ),
                              const SizedBox(height: 12),
                              Text(
                                isAr
                                    ? 'تعذّر تحميل الصورة'
                                    : 'Failed to load image',
                                style: const TextStyle(color: Colors.white54),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
            ),
            Container(
              color: Colors.black,
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _retrying ? null : _retry,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.white38),
                        minimumSize: const Size.fromHeight(50),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24),
                        ),
                      ),
                      icon: const Icon(Icons.refresh, size: 18),
                      label: Text(s.aiResultRetryButton),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.black,
                        minimumSize: const Size.fromHeight(50),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24),
                        ),
                      ),
                      icon: const Icon(Icons.shopping_bag_outlined, size: 18),
                      label: Text(s.aiResultBuyButton),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}